## Auto-Spare-Parts-Management
This is my TE IT DBMS mini project, using MySQL and PHP3.
This is a web based Application to manage sales of Auto spare parts.

### Installation
* Install XAMPP
* Clone the repository and move to the C:\xampp\htdocs
* Open PHPMyAdmin create new DB (spare_parts)
* Import spare_parts.sql from this repo. to newly created DB
* Now you're all done! just open in browser - http://localhost/spare_parts_management

![Screenshot (135)](https://user-images.githubusercontent.com/47142604/99874514-a2f40f00-2c0e-11eb-8528-f8fa9a266723.png)
![Screenshot (136)](https://user-images.githubusercontent.com/47142604/99874516-a5566900-2c0e-11eb-9493-2d97a6caa5d3.png)
![Screenshot (137)](https://user-images.githubusercontent.com/47142604/99874517-a6879600-2c0e-11eb-887e-002f7a624f5b.png)
![Screenshot (138)](https://user-images.githubusercontent.com/47142604/99874518-a8515980-2c0e-11eb-8a24-768e34d865d7.png)
![Screenshot (139)](https://user-images.githubusercontent.com/47142604/99874520-aa1b1d00-2c0e-11eb-8e3d-8a2193df69ba.png)
![Screenshot (140)](https://user-images.githubusercontent.com/47142604/99874521-abe4e080-2c0e-11eb-9da0-b5f1b8c4b7ac.png)
![Screenshot (141)](https://user-images.githubusercontent.com/47142604/99874522-ad160d80-2c0e-11eb-9aba-e464b1961416.png)
![Screenshot (142)](https://user-images.githubusercontent.com/47142604/99874525-b4d5b200-2c0e-11eb-98cc-77e219bad79b.png)
![Screenshot (143)](https://user-images.githubusercontent.com/47142604/99874527-b7d0a280-2c0e-11eb-8aaa-584c65e97ca4.png)
![Screenshot (144)](https://user-images.githubusercontent.com/47142604/99874529-b99a6600-2c0e-11eb-9ef8-ca652700f2b5.png)
![Screenshot (145)](https://user-images.githubusercontent.com/47142604/99874532-c028dd80-2c0e-11eb-981d-4428dbd11ef4.png)
![Screenshot (146)](https://user-images.githubusercontent.com/47142604/99874534-c1f2a100-2c0e-11eb-969e-85e0816034d6.png)
![Screenshot (147)](https://user-images.githubusercontent.com/47142604/99874537-c7e88200-2c0e-11eb-94f7-a95ce3e9a749.png)
![Screenshot (148)](https://user-images.githubusercontent.com/47142604/99874538-ca4adc00-2c0e-11eb-8551-f3ccbed14138.png)
![Screenshot (149)](https://user-images.githubusercontent.com/47142604/99874539-cc149f80-2c0e-11eb-96c4-60ed5d8f8562.png)
![Screenshot (150)](https://user-images.githubusercontent.com/47142604/99874542-cdde6300-2c0e-11eb-96c8-6bf28a9763cf.png)
![Screenshot (151)](https://user-images.githubusercontent.com/47142604/99874543-cf0f9000-2c0e-11eb-86e1-b88d21744a32.png)
![Screenshot (152)](https://user-images.githubusercontent.com/47142604/99874546-d59e0780-2c0e-11eb-97aa-741cad2b4679.png)
![Screenshot (153)](https://user-images.githubusercontent.com/47142604/99874549-d8006180-2c0e-11eb-97e4-b74c5748ef66.png)

## Connect with me:  
<a href="https://instagram.com/p4v4n" target="blank"><img align="center" src="https://github.com/pavanpatil45/pavanpatil45/blob/main/connect with me/insta.png" alt="instagram" width="30" /></a>&nbsp;
<a href="https://stackoverflow.com/users/14926087/pavan-patil?tab=profile " target="blank"><img align="center" src="https://github.com/pavanpatil45/pavanpatil45/blob/main/connect with me/stack.svg" alt="stack-overflow" height="30" width="30" /></a>&nbsp;
<a href="https://linkedin.com/in/pavan-patil-445a33150" target="blank"><img align="center" src="https://github.com/pavanpatil45/pavanpatil45/blob/main/connect with me/linkedin.webp" alt="linkedin" height="30" width="30" /></a>&nbsp;
<a href="https://twitter.com/pavanpatil45" target="blank"><img align="center" src="https://github.com/pavanpatil45/pavanpatil45/blob/main/connect with me/twitter.png" alt="twitter" width="30" /></a>&nbsp;
<a href="https://facebook.com/pavanpatil450" target="blank"><img align="center" src="https://github.com/pavanpatil45/pavanpatil45/blob/main/connect with me/facebook.webp" alt="facebook" height="30" width="30" /></a>&nbsp;
<a href="https://www.reddit.com/user/p4v4n_45" target="blank"><img align="center" src="https://github.com/pavanpatil45/pavanpatil45/blob/main/connect with me/reddit.svg" alt="reddit" width="30" /></a>&nbsp;

